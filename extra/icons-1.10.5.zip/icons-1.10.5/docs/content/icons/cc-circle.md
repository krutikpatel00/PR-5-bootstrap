---
title: CC circle
categories:
  - Shapes
tags:
  - "creative commons"
---

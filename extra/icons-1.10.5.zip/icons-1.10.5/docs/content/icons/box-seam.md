---
title: Box seam
categories:
  - Real world
tags:
  - cardboard
  - package
---
